export default function snippetShowLoadingPage() {
  return <div>Loading...</div>;
}
