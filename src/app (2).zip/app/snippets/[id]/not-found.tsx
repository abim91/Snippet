export default function SnippetNotFound() {
  return (
    <div>
      <h1 className="text-xl bold">Sorry This Page Has Not Been Created Yet</h1>
    </div>
  );
}
