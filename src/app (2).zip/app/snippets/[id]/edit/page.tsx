interface SnippetEditPage {
  params: {
    id: string;
  };
}
export default async function SnippetEditPage(props: string) {
  console.log(props);
  // const id = parseInt(props.params.id);
  // return <div>Editing snippet with id {id}</div>;
  return <div>testing edit route</div>;
}
